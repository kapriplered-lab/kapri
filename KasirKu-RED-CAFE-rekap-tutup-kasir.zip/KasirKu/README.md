# KasirKu — RED CAFE (revisi bertahap)

Proyek Android native Java untuk kasir offline. Ini adalah **kode sumber**, bukan APK yang sudah dikompilasi atau diuji.

## Yang ditambahkan pada revisi ini
- Aset logo RED CAFE dari gambar yang diberikan pengguna.
- Tema warna merah marun dan krem.
- Catatan pada baris item di keranjang (misalnya extra shot), tersimpan bersama item transaksi.
- Struk pelanggan dan tiket racikan terpisah; tiket racikan tidak memuat harga.
- Nama kasir dan pesan struk dapat diatur.
- Rekap harian memisahkan tunai dan QRIS, serta riwayat dapat melihat transaksi dari semua tanggal.
- Cetak ulang struk/tiket dari riwayat tidak membuat transaksi baru.

## Fitur yang masih perlu dikerjakan
- Backup dan restore data melalui file yang dapat dipilih pengguna.
- Pengujian kompilasi dan uji perangkat/printer sebenarnya.
- Validasi pembaruan APK terhadap signature/keystore APK yang terpasang.

## Build APK
1. Buka folder `KasirKu` di Android Studio dengan dukungan Android Gradle Plugin 8.6.1.
2. Pastikan Android SDK Platform 35 terpasang.
3. Jalankan Gradle Sync, lalu **Build > Build APK(s)**.
4. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Penting
- Jangan uninstall APK lama atau hapus data aplikasi sebelum backup tersedia dan diuji.
- APK update harus memakai application ID dan signing key yang cocok dengan aplikasi yang terpasang. Kode sumber yang sama tidak menjamin signing key yang sama.
- QRIS/transfer masih berupa konfirmasi manual, bukan integrasi penyedia pembayaran.
- Printer harus mendukung Bluetooth Classic SPP/ESC-POS; kompatibilitas tergantung model.
