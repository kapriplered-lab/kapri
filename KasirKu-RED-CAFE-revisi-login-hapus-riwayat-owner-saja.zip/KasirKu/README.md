# KasirKu — RED CAFE (revisi bertahap)

Proyek Android native Java untuk kasir offline. Ini adalah **kode sumber**, bukan APK yang sudah dikompilasi atau diuji.

## Fitur pada revisi ini
- Aset logo RED CAFE dan tema merah marun/krem.
- Login lokal menggunakan username dan password untuk owner serta kasir.
- Pada penggunaan pertama, buat akun owner. Setelah login, owner dapat membuat dan menghapus akun kasir melalui Pengaturan.
- Password disimpan sebagai hash, bukan teks biasa. Akun tersimpan lokal pada perangkat ini.
- Tambah katalog dan hapus produk dengan konfirmasi; penghapusan produk tidak menghapus item pada transaksi lama.
- Catatan item di keranjang (misalnya extra shot), tersimpan bersama item transaksi.
- Struk pelanggan dan tiket dapur terpisah; tiket dapur tidak memuat harga.
- Rekap harian tunai/QRIS, jumlah transaksi, daftar produk terjual, dan riwayat transaksi semua tanggal.
- Cetak ulang struk/tiket dan rekap tanpa membuat transaksi baru.
- Hapus transaksi dari riwayat dengan konfirmasi; transaksi yang dihapus tidak lagi dihitung dalam rekap.
- Backup/restore data melalui file, serta pengaturan printer Bluetooth 58 mm.

## Build APK
1. Buka folder `KasirKu` di Android Studio dengan dukungan Android Gradle Plugin 8.6.1.
2. Pastikan Android SDK Platform 35 terpasang.
3. Jalankan Gradle Sync, lalu **Build > Build APK(s)**.
4. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Penting
- Akun login bersifat lokal pada satu perangkat; belum ada sinkronisasi cloud antarperangkat.
- Jangan uninstall APK lama atau hapus data aplikasi sebelum backup tersedia dan diuji.
- APK update harus memakai application ID dan signing key yang cocok dengan aplikasi yang terpasang. Kode sumber yang sama tidak menjamin signing key yang sama.
- QRIS/transfer masih berupa konfirmasi manual, bukan integrasi penyedia pembayaran.
- Printer harus mendukung Bluetooth Classic SPP/ESC-POS; kompatibilitas tergantung model.
- Build Android dan pengujian perangkat/printer harus dilakukan sebelum APK dinyatakan siap.
