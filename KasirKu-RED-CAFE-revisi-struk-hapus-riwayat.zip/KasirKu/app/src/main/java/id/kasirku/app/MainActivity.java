package id.kasirku.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.UUID;

public class MainActivity extends Activity {
    private final String[] tabs={"Katalog","Keranjang","Pembayaran","Rekap Harian","Bluetooth","Pengaturan"};
    private final int green=0xFF8E1425, dark=0xFF5B101B, pale=0xFFFFF7E8;
    private LinearLayout root, body, nav;
    private SharedPreferences prefs;
    private final ArrayList<Product> products=new ArrayList<>();
    private final LinkedHashMap<Integer,Integer> cart=new LinkedHashMap<>();
    private final ArrayList<JSONObject> sales=new ArrayList<>();
    private String current="Katalog", printerAddress="";
    private final LinkedHashMap<Integer,String> cartNotes=new LinkedHashMap<>();
    private EditText paidInput;
    private TextView totalLabel, changeLabel;
    private static final int REQ_BACKUP=2201, REQ_RESTORE=2202;
    private static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    static class Product { int id; String name,cat; long price; Product(int i,String n,String c,long p){id=i;name=n;cat=c;price=p;} }

    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("kasirku",MODE_PRIVATE); loadData(); show("Katalog");}
    private void loadData(){
        products.clear();
        String raw=prefs.getString("products",null);
        try { if(raw!=null){JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);products.add(new Product(o.getInt("id"),o.getString("name"),o.getString("cat"),o.getLong("price")));}} } catch(Exception ignored){}
        if(products.isEmpty()){products.add(new Product(1,"Air Mineral","Minuman",4000));products.add(new Product(2,"Kopi Sachet","Minuman",2500));products.add(new Product(3,"Mie Instan","Makanan",3500));products.add(new Product(4,"Roti","Makanan",5000));products.add(new Product(5,"Teh Botol","Minuman",5000));products.add(new Product(6,"Biskuit","Snack",7000));products.add(new Product(7,"Susu Kotak","Minuman",6000));products.add(new Product(8,"Permen","Snack",1000));saveProducts();}
        printerAddress=prefs.getString("printer","");
        try{JSONArray a=new JSONArray(prefs.getString("sales","[]"));for(int i=0;i<a.length();i++)sales.add(a.getJSONObject(i));}catch(Exception ignored){}
    }
    private void saveProducts(){try{JSONArray a=new JSONArray();for(Product p:products){JSONObject o=new JSONObject();o.put("id",p.id);o.put("name",p.name);o.put("cat",p.cat);o.put("price",p.price);a.put(o);}prefs.edit().putString("products",a.toString()).apply();}catch(Exception ignored){}}
    private void saveSales(){JSONArray a=new JSONArray();for(JSONObject s:sales)a.put(s);prefs.edit().putString("sales",a.toString()).apply();}
    private long total(){long n=0;for(Map.Entry<Integer,Integer> e:cart.entrySet()){Product p=find(e.getKey());if(p!=null)n+=p.price*e.getValue();}return n;}
    private int quantity(){int n=0;for(int q:cart.values())n+=q;return n;}
    private Product find(int id){for(Product p:products)if(p.id==id)return p;return null;}
    private String rp(long n){return "Rp"+String.format(new Locale("id","ID"),"%,d",n).replace(',','.');}
    private String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    private String now(){return new SimpleDateFormat("dd/MM/yyyy HH:mm",new Locale("id","ID")).format(new Date());}

    private void show(String tab){current=tab;root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xFFF7F8F7);setContentView(root);
        LinearLayout header=new LinearLayout(this);header.setPadding(18,16,18,16);header.setGravity(Gravity.CENTER_VERTICAL);header.setBackgroundColor(dark);header.setOrientation(LinearLayout.VERTICAL);
        ImageView logo=new ImageView(this); int logoId=getResources().getIdentifier("red_cafe_logo","drawable",getPackageName()); if(logoId!=0){logo.setImageResource(logoId);logo.setAdjustViewBounds(true);logo.setMaxHeight(86);header.addView(logo,new LinearLayout.LayoutParams(-1,86));} TextView brand=text("RED CAFE",24,0xFFFFFFFF,true);header.addView(brand);TextView sub=text("Kasir offline • Struk Bluetooth 58 mm",12,0xFFFFE8D0,false);header.addView(sub);root.addView(header);
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);nav=new LinearLayout(this);nav.setPadding(6,7,6,7);nav.setOrientation(LinearLayout.HORIZONTAL);hsv.addView(nav);root.addView(hsv);
        for(String t:tabs){Button b=button(t);b.setTextSize(12);b.setAllCaps(false);b.setPadding(12,8,12,8);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(current.equals(t)?green:0xFFE2E9E4));b.setTextColor(current.equals(t)?0xFFFFFFFF:dark);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.setMargins(3,0,3,0);nav.addView(b,lp);b.setOnClickListener(v->show(t));}
        ScrollView scroll=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(16,14,16,24);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        switch(tab){case "Katalog":catalog();break;case "Keranjang":cartPage();break;case "Pembayaran":payment();break;case "Rekap Harian":report();break;case "Bluetooth":bluetoothPage();break;case "Pengaturan":settingsPage();break;}
    }
    private TextView text(String s,int size,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);if(bold)v.setTypeface(null,Typeface.BOLD);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    private void heading(String s){TextView t=text(s,21,dark,true);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=12;body.addView(t,p);}
    private void line(){View v=new View(this);v.setBackgroundColor(0xFFDDE5DF);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,1);p.topMargin=9;p.bottomMargin=9;body.addView(v,p);}
    private void label(String s){TextView t=text(s,14,0xFF34483D,false);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=8;p.bottomMargin=5;body.addView(t,p);}
    private void addButton(String s,Runnable action){Button b=button(s);b.setTextColor(0xFFFFFFFF);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=9;body.addView(b,p);b.setOnClickListener(v->action.run());}
    private void catalog(){heading("Katalog Produk");EditText search=new EditText(this);search.setSingleLine(true);search.setHint("Cari produk...");body.addView(search);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);Runnable fill=()->{list.removeAllViews();String q=search.getText().toString().toLowerCase(Locale.ROOT);for(Product p:products){if(!p.name.toLowerCase(Locale.ROOT).contains(q)&&!p.cat.toLowerCase(Locale.ROOT).contains(q))continue;LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(12,10,6,10);row.setBackgroundColor(0xFFFFFFFF);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,5,0,5);list.addView(row,rp);LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.addView(text(p.name,16,dark,true));info.addView(text(p.cat+" • "+rp(p.price),13,green,false));row.addView(info,new LinearLayout.LayoutParams(0,-2,1));Button add=button("+ Tambah");add.setOnClickListener(v->{cart.put(p.id,cart.getOrDefault(p.id,0)+1);Toast.makeText(this,p.name+" ditambahkan",Toast.LENGTH_SHORT).show();});row.addView(add);}};fill.run();search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){fill.run();}public void afterTextChanged(android.text.Editable e){}});addButton("Buka Keranjang ("+quantity()+") • "+rp(total()),()->show("Keranjang"));addButton("+ Tambah Produk Baru",()->addProductDialog());}
    private void addProductDialog(){LinearLayout form=new LinearLayout(this);form.setPadding(18,4,18,4);form.setOrientation(LinearLayout.VERTICAL);EditText name=new EditText(this);name.setHint("Nama produk");form.addView(name);EditText cat=new EditText(this);cat.setHint("Kategori, contoh: Minuman");form.addView(cat);EditText price=new EditText(this);price.setHint("Harga (angka)");price.setInputType(InputType.TYPE_CLASS_NUMBER);form.addView(price);new AlertDialog.Builder(this).setTitle("Tambah Produk").setView(form).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{try{String n=name.getText().toString().trim();long pr=Long.parseLong(price.getText().toString());if(n.isEmpty()||pr<0)throw new Exception();int id=1;for(Product p:products)id=Math.max(id,p.id+1);products.add(new Product(id,n,cat.getText().toString().trim(),pr));saveProducts();show("Katalog");}catch(Exception e){Toast.makeText(this,"Nama dan harga valid wajib diisi",Toast.LENGTH_LONG).show();}}).show();}
    private void cartPage(){
        heading("Keranjang Belanja");
        if(cart.isEmpty()){body.addView(text("Keranjang masih kosong. Tambahkan produk dari katalog.",15,0xFF65756B,false));addButton("Buka Katalog",()->show("Katalog"));return;}
        ArrayList<Integer> ids=new ArrayList<>(cart.keySet());
        for(int id:ids){Product p=find(id);if(p==null)continue;
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(12,10,12,10);row.setBackgroundColor(0xFFFFFFFF);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,4,0,4);body.addView(row,lp);
            row.addView(text(p.name+" — "+rp(p.price),16,dark,true));row.addView(text("Subtotal: "+rp(p.price*cart.get(id)),14,green,false));
            EditText note=new EditText(this);note.setSingleLine(true);note.setTextSize(14);note.setHint("Catatan item (contoh: extra shot)");note.setText(cartNotes.getOrDefault(id,""));row.addView(note);note.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){cartNotes.put(id,s.toString());}public void afterTextChanged(android.text.Editable e){}});
            LinearLayout controls=new LinearLayout(this);row.addView(controls);Button minus=button("−"),count=button("Qty: "+cart.get(id)),plus=button("+"),del=button("Hapus");controls.addView(minus);controls.addView(count);controls.addView(plus);controls.addView(del);
            minus.setOnClickListener(v->{int q=cart.get(id)-1;if(q<=0){cart.remove(id);cartNotes.remove(id);}else cart.put(id,q);show("Keranjang");});plus.setOnClickListener(v->{cart.put(id,cart.get(id)+1);show("Keranjang");});del.setOnClickListener(v->{cart.remove(id);cartNotes.remove(id);show("Keranjang");});
        }
        line();body.addView(text("Total: "+rp(total()),22,green,true));body.addView(text("Jumlah barang: "+quantity(),14,dark,false));addButton("Lanjut Pembayaran",()->show("Pembayaran"));
    }
    private void payment(){heading("Pembayaran");long sum=total();TextView totalView=text("TOTAL BELANJA\n"+rp(sum),24,green,true);totalView.setPadding(12,18,12,18);totalView.setBackgroundColor(pale);body.addView(totalView);if(cart.isEmpty()){label("Belum ada transaksi aktif.");addButton("Pilih Produk",()->show("Katalog"));return;}label("Tipe pesanan");Spinner orderType=new Spinner(this);String[] orderTypes={"Dine In","Take Away"};orderType.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,orderTypes));body.addView(orderType);label("Uang diterima (Rp)");paidInput=new EditText(this);paidInput.setSingleLine(true);paidInput.setInputType(InputType.TYPE_CLASS_NUMBER);paidInput.setHint("Masukkan uang pelanggan");paidInput.setText(String.valueOf(sum));body.addView(paidInput);LinearLayout quick=new LinearLayout(this);quick.setOrientation(LinearLayout.HORIZONTAL);body.addView(quick);for(long n:new long[]{sum,20000,50000,100000}){Button b=button(n==sum?"Uang Pas":(n/1000)+"rb");b.setTextSize(11);quick.addView(b,new LinearLayout.LayoutParams(0,-2,1));b.setOnClickListener(v->paidInput.setText(String.valueOf(n)));}changeLabel=text("Uang pas",18,dark,true);changeLabel.setPadding(4,14,4,14);body.addView(changeLabel);paidInput.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){updateChange(sum);}public void afterTextChanged(android.text.Editable e){}});updateChange(sum);label("Metode pembayaran");RadioGroup rg=new RadioGroup(this);RadioButton cash=new RadioButton(this);cash.setText("Tunai");cash.setChecked(true);RadioButton qris=new RadioButton(this);qris.setText("QRIS (konfirmasi manual)");RadioButton transfer=new RadioButton(this);transfer.setText("Transfer (konfirmasi manual)");rg.addView(cash);rg.addView(qris);rg.addView(transfer);body.addView(rg);addButton("Selesaikan Pembayaran",()->{String method=rg.getCheckedRadioButtonId()==qris.getId()?"QRIS":rg.getCheckedRadioButtonId()==transfer.getId()?"Transfer":"Tunai";long parsedPaid=0;try{parsedPaid=Long.parseLong(paidInput.getText().toString());}catch(Exception ignored){}final long paid=parsedPaid;if(method.equals("Tunai")&&paid<sum){Toast.makeText(this,"Uang pembayaran masih kurang",Toast.LENGTH_SHORT).show();return;}if(method.equals("Tunai")&&paid==0){Toast.makeText(this,"Masukkan uang yang diterima",Toast.LENGTH_SHORT).show();return;}new AlertDialog.Builder(this).setTitle("Konfirmasi Pembayaran").setMessage("Total "+rp(sum)+"\nMetode: "+method+(method.equals("Tunai")?"\nDibayar: "+rp(paid)+"\nKembalian: "+rp(paid-sum):"\nPastikan pembayaran sudah diterima.")).setNegativeButton("Batal",null).setPositiveButton("Simpan Transaksi",(d,w)->completeSale(sum,paid,method,orderType.getSelectedItem().toString())).show();});}
    private void updateChange(long sum){if(changeLabel==null||paidInput==null)return;long n=0;try{n=Long.parseLong(paidInput.getText().toString());}catch(Exception ignored){}if(n<sum){changeLabel.setText("Uang kurang: "+rp(sum-n));changeLabel.setTextColor(0xFFB3261E);}else if(n==sum){changeLabel.setText("Uang pas ✓");changeLabel.setTextColor(green);}else{changeLabel.setText("Kembalian: "+rp(n-sum));changeLabel.setTextColor(green);}}
    private void completeSale(long sum,long paid,String method,String orderType){try{JSONObject s=new JSONObject();s.put("id",UUID.randomUUID().toString());s.put("date",today());s.put("time",now());s.put("total",sum);s.put("paid",paid);s.put("change",Math.max(0,paid-sum));s.put("method",method);s.put("orderType",orderType);int dailyNumber=1;for(JSONObject previous:sales)if(today().equals(previous.optString("date")))dailyNumber=Math.max(dailyNumber,previous.optInt("orderNo",0)+1);s.put("orderNo",dailyNumber);s.put("cashier",prefs.getString("cashier","Kasir"));JSONArray items=new JSONArray();for(Map.Entry<Integer,Integer> e:cart.entrySet()){Product p=find(e.getKey());if(p!=null){JSONObject o=new JSONObject();o.put("name",p.name);o.put("qty",e.getValue());o.put("price",p.price);o.put("note",cartNotes.getOrDefault(p.id,""));items.put(o);}}s.put("items",items);sales.add(s);saveSales();String customerReceipt=receipt(s);String kitchen=kitchenTicket(s);cart.clear();cartNotes.clear();show("Pembayaran");new AlertDialog.Builder(this).setTitle("Transaksi Berhasil").setMessage("Transaksi tersimpan offline.\nTotal: "+rp(sum)+"\nKembalian: "+rp(Math.max(0,paid-sum))).setNegativeButton("Tutup",null).setNeutralButton("Tiket Racikan",(d,w)->printReceipt(kitchen)).setPositiveButton("Cetak Struk",(d,w)->printReceipt(customerReceipt)).show();}catch(Exception e){Toast.makeText(this,"Gagal menyimpan transaksi",Toast.LENGTH_LONG).show();}}
    private String transactionNo(JSONObject s){
        int number=s.optInt("orderNo",0);
        if(number<=0){number=1;for(JSONObject previous:sales){if(previous==s)break;if(s.optString("date").equals(previous.optString("date")))number++;}}
        return String.format(Locale.US,"%03d",number);
    }
    private String receipt(JSONObject s){
        StringBuilder b=new StringBuilder();
        b.append("          RED CAFE\n");
        b.append(prefs.getString("receipt_message","COFFEE • CLASSIC")).append("\n");
        b.append("------------------------------\n");
        b.append("NO. TRANSAKSI: #").append(transactionNo(s)).append("\n");
        b.append("Waktu: ").append(s.optString("time")).append("\n");
        b.append("Tipe: ").append(s.optString("orderType","Dine In")).append("\n");
        b.append("Kasir: ").append(s.optString("cashier","Kasir")).append("\n");
        b.append("------------------------------\n");
        long calculated=0;
        try{JSONArray a=s.getJSONArray("items");for(int i=0;i<a.length();i++){
            JSONObject o=a.getJSONObject(i);long subtotal=o.optInt("qty")*o.optLong("price");calculated+=subtotal;
            b.append(o.optString("name")).append("\n");
            b.append(o.optInt("qty")).append(" x ").append(rp(o.optLong("price"))).append(" = ").append(rp(subtotal)).append("\n");
            String note=o.optString("note","").trim();if(!note.isEmpty())b.append("  Catatan: ").append(note).append("\n");
        }}catch(Exception ignored){}
        b.append("------------------------------\n");
        b.append("SUBTOTAL: ").append(rp(s.optLong("total",calculated))).append("\n");
        b.append("TOTAL: ").append(rp(s.optLong("total",calculated))).append("\n");
        b.append("PEMBAYARAN ").append(s.optString("method")).append("\n");
        b.append("DIBAYAR: ").append(rp(s.optLong("paid"))).append("\n");
        b.append("KEMBALI: ").append(rp(s.optLong("change"))).append("\n");
        b.append("------------------------------\nTerima kasih\nDatang kembali!\n\n\n");
        return b.toString();
    }
    private String kitchenTicket(JSONObject s){
        StringBuilder b=new StringBuilder();
        b.append("          RED CAFE\n");
        b.append("       TIKET DAPUR\n");
        b.append("==============================\n");
        b.append("       PESANAN #").append(transactionNo(s)).append("\n");
        b.append("==============================\n");
        b.append("TIPE: ").append(s.optString("orderType","Dine In")).append("\n");
        b.append("ORDER: #").append(transactionNo(s)).append("\n");
        b.append("WAKTU: ").append(s.optString("time")).append("\n");
        b.append("KASIR: ").append(s.optString("cashier","Kasir")).append("\n");
        b.append("------------------------------\n");
        try{JSONArray a=s.getJSONArray("items");for(int i=0;i<a.length();i++){
            JSONObject o=a.getJSONObject(i);
            b.append("\n").append(o.optInt("qty")).append(" x ").append(o.optString("name")).append("\n");
            String note=o.optString("note","").trim();if(!note.isEmpty())b.append("  CATATAN: ").append(note).append("\n");
        }}catch(Exception ignored){}
        b.append("\n------------------------------\n\n\n");
        return b.toString();
    }
    private String dailyClosingReceipt(){
        long sum=0,cashSum=0,qrisSum=0,otherSum=0;int count=0;
        StringBuilder b=new StringBuilder();
        b.append("          RED CAFE\n   REKAP TUTUP KASIR\n");
        b.append("------------------------------\nTanggal: ").append(today()).append("\nDicetak: ").append(now()).append("\n");
        b.append("------------------------------\nDAFTAR TRANSAKSI\n");
        LinkedHashMap<String,Integer> sold=new LinkedHashMap<>();
        for(JSONObject s:sales)if(today().equals(s.optString("date"))){
            long v=s.optLong("total");sum+=v;count++;String m=s.optString("method");
            if(m.equals("Tunai"))cashSum+=v;else if(m.equals("QRIS"))qrisSum+=v;else otherSum+=v;
            b.append("#").append(transactionNo(s)).append(" ").append(s.optString("time")).append("\n");
            b.append("  Subtotal: ").append(rp(v)).append("\n");
            try{JSONArray items=s.getJSONArray("items");for(int i=0;i<items.length();i++){JSONObject it=items.getJSONObject(i);String name=it.optString("name");sold.put(name,sold.getOrDefault(name,0)+it.optInt("qty"));}}catch(Exception ignored){}
        }
        b.append("------------------------------\nRINGKASAN AKHIR\n");
        b.append("Jumlah transaksi: ").append(count).append("\nTunai/Cash: ").append(rp(cashSum)).append("\nQRIS: ").append(rp(qrisSum)).append("\n");
        if(otherSum>0)b.append("Transfer/lainnya: ").append(rp(otherSum)).append("\n");
        b.append("TOTAL PENJUALAN: ").append(rp(sum)).append("\n");
        b.append("------------------------------\nPRODUK TERJUAL\n");
        if(sold.isEmpty())b.append("Belum ada produk terjual\n");
        else for(Map.Entry<String,Integer> item:sold.entrySet())b.append(item.getKey()).append(" x ").append(item.getValue()).append("\n");
        b.append("------------------------------\nRekap berdasarkan transaksi tersimpan.\n\n\n");
        return b.toString();
    }
    private void report(){heading("Rekap Harian");long sum=0,cashSum=0,qrisSum=0,otherSum=0;int count=0;for(JSONObject s:sales)if(today().equals(s.optString("date"))){long v=s.optLong("total");sum+=v;count++;String m=s.optString("method");if(m.equals("Tunai"))cashSum+=v;else if(m.equals("QRIS"))qrisSum+=v;else otherSum+=v;}TextView card=text("PENJUALAN HARI INI\n"+rp(sum),24,green,true);card.setPadding(14,18,14,18);card.setBackgroundColor(pale);body.addView(card);line();body.addView(text("Jumlah transaksi: "+count,17,dark,true));body.addView(text("Tunai: "+rp(cashSum),15,dark,false));body.addView(text("QRIS: "+rp(qrisSum),15,dark,false));if(otherSum>0)body.addView(text("Transfer/lainnya: "+rp(otherSum),15,dark,false));body.addView(text("Rata-rata transaksi: "+rp(count==0?0:sum/count),15,dark,false));addButton("Cetak Rekap Tutup Kasir",()->new AlertDialog.Builder(this).setTitle("Cetak Rekap Tutup Kasir?").setMessage("Rekap hari ini akan dicetak. Ini tidak membuat transaksi baru.").setNegativeButton("Batal",null).setPositiveButton("Cetak",(d,w)->printReceipt(dailyClosingReceipt())).show());addButton("Cetak Ulang Rekap Tutup Kasir",()->printReceipt(dailyClosingReceipt()));heading("Riwayat Transaksi (semua tanggal)");if(sales.isEmpty())body.addView(text("Belum ada transaksi.",14,0xFF65756B,false));for(int i=sales.size()-1;i>=0;i--){JSONObject s=sales.get(i);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(10,10,10,10);r.setBackgroundColor(0xFFFFFFFF);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,4,0,4);body.addView(r,lp);r.addView(text(s.optString("date")+" • "+s.optString("time")+" • "+s.optString("method"),13,0xFF65756B,false));r.addView(text(rp(s.optLong("total")),17,dark,true));Button print=button("Cetak Ulang Struk");r.addView(print);print.setOnClickListener(v->printReceipt(receipt(s)));Button kitchen=button("Cetak Ulang Tiket Racikan");r.addView(kitchen);kitchen.setOnClickListener(v->printReceipt(kitchenTicket(s)));Button delete=button("Hapus Transaksi dari Riwayat");delete.setTextColor(0xFFFFFFFF);delete.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFB3261E));r.addView(delete);delete.setOnClickListener(v->confirmDeleteSale(s));}}
    private void confirmDeleteSale(JSONObject sale){
        String id=sale.optString("id","");
        new AlertDialog.Builder(this)
            .setTitle("Hapus transaksi?")
            .setMessage("Transaksi "+sale.optString("date")+" • "+sale.optString("time")+" dengan total "+rp(sale.optLong("total"))+" akan dihapus dari riwayat dan tidak lagi dihitung dalam rekap harian. Struk kertas yang sudah tercetak tidak ikut terhapus. Tindakan ini tidak bisa dibatalkan.\n\nJika pelanggan hanya mengganti pesanan, hapus transaksi ini lalu buat transaksi baru dengan pesanan yang benar.")
            .setNegativeButton("Batal",null)
            .setPositiveButton("Ya, Hapus",(dialog,which)->{
                boolean removed=false;
                for(int i=sales.size()-1;i>=0;i--){
                    JSONObject existing=sales.get(i);
                    if(existing==sale || (!id.isEmpty() && id.equals(existing.optString("id","")))){sales.remove(i);removed=true;break;}
                }
                if(removed){saveSales();Toast.makeText(this,"Transaksi dihapus dari riwayat dan rekap",Toast.LENGTH_LONG).show();show("Rekap Harian");}
                else Toast.makeText(this,"Transaksi tidak ditemukan",Toast.LENGTH_SHORT).show();
            }).show();
    }
    private JSONObject createBackup() throws Exception {
        JSONObject root=new JSONObject();
        root.put("format", "KasirKuBackup");
        root.put("version", 1);
        root.put("created_at", now());
        root.put("products", prefs.getString("products", "[]"));
        root.put("sales", prefs.getString("sales", "[]"));
        root.put("cashier", prefs.getString("cashier", "Kasir"));
        root.put("receipt_message", prefs.getString("receipt_message", "COFFEE • CLASSIC"));
        root.put("printer", prefs.getString("printer", ""));
        return root;
    }
    private void startBackup(){
        android.content.Intent i=new android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(android.content.Intent.EXTRA_TITLE, "KasirKu-Backup-"+today()+".json");
        startActivityForResult(i, REQ_BACKUP);
    }
    private void startRestore(){
        new AlertDialog.Builder(this).setTitle("Pulihkan Backup?")
            .setMessage("Data produk dan riwayat saat ini akan diganti dengan isi backup. Pastikan file backup benar.")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Pilih File", (d,w)->{
                android.content.Intent i=new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                startActivityForResult(i, REQ_RESTORE);
            }).show();
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK || data==null || data.getData()==null)return;
        android.net.Uri uri=data.getData();
        if(requestCode==REQ_BACKUP){
            try(OutputStream out=getContentResolver().openOutputStream(uri)){
                if(out==null)throw new IOException("File tidak bisa ditulis");
                out.write(createBackup().toString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8));
                out.flush(); toast("Backup berhasil disimpan. Simpan file ini di tempat aman.");
            }catch(Exception e){toast("Backup gagal: "+e.getMessage());}
        }else if(requestCode==REQ_RESTORE){
            try(InputStream in=getContentResolver().openInputStream(uri); ByteArrayOutputStream buffer=new ByteArrayOutputStream()){
                if(in==null)throw new IOException("File tidak bisa dibaca");
                byte[] chunk=new byte[4096]; int n; while((n=in.read(chunk))!=-1)buffer.write(chunk,0,n);
                JSONObject backup=new JSONObject(new String(buffer.toByteArray(), java.nio.charset.StandardCharsets.UTF_8));
                if(!"KasirKuBackup".equals(backup.optString("format")))throw new IOException("Format backup tidak dikenali");
                JSONArray p=new JSONArray(backup.getString("products"));
                JSONArray salesCheck=new JSONArray(backup.getString("sales"));
                prefs.edit().putString("products",p.toString()).putString("sales",salesCheck.toString())
                    .putString("cashier",backup.optString("cashier","Kasir"))
                    .putString("receipt_message",backup.optString("receipt_message","COFFEE • CLASSIC"))
                    .putString("printer",backup.optString("printer", "")).apply();
                products.clear(); sales.clear(); cart.clear(); cartNotes.clear(); loadData();
                toast("Restore berhasil. Periksa katalog dan riwayat sebelum digunakan."); show("Pengaturan");
            }catch(Exception e){toast("Restore gagal. Data tidak dipulihkan: "+e.getMessage());}
        }
    }

    private void settingsPage(){heading("Pengaturan RED CAFE");label("Nama kasir");EditText cashier=new EditText(this);cashier.setSingleLine(true);cashier.setHint("Nama kasir");cashier.setText(prefs.getString("cashier","Kasir"));body.addView(cashier);label("Pesan pada struk");EditText message=new EditText(this);message.setSingleLine(false);message.setMinLines(2);message.setHint("Contoh: Terima kasih, datang kembali!");message.setText(prefs.getString("receipt_message","COFFEE • CLASSIC"));body.addView(message);addButton("Simpan Pengaturan",()->{String c=cashier.getText().toString().trim();String m=message.getText().toString().trim();prefs.edit().putString("cashier",c.isEmpty()?"Kasir":c).putString("receipt_message",m.isEmpty()?"Terima kasih!":m).apply();toast("Pengaturan tersimpan");});line();heading("Data & Backup");body.addView(text("Simpan salinan produk, riwayat transaksi, dan pengaturan sebagai file JSON. Simpan file di lokasi aman sebelum update APK.",14,dark,false));addButton("Buat Backup ke File",()->startBackup());addButton("Pulihkan dari File Backup",()->startRestore());body.addView(text("Peringatan: restore mengganti produk dan riwayat yang ada dengan isi backup. Buat backup terbaru sebelum memulihkan.",13,0xFF8E1425,false));}
    private void bluetoothPage(){heading("Printer Bluetooth 58 mm");body.addView(text(printerAddress.isEmpty()?"Printer belum dipilih.":"Printer tersimpan: "+printerAddress,15,dark,true));addButton("Pilih Printer yang Sudah Dipasangkan",()->choosePrinter());addButton("Cetak Struk Uji",()->printReceipt("       RED CAFE\n------------------------------\nTES PRINTER BLUETOOTH\nKertas 58 mm\nKoneksi berhasil jika teks ini tercetak.\n\n\n"));label("Catatan");body.addView(text("Pasangkan printer terlebih dahulu melalui Pengaturan Bluetooth Android. Printer harus mendukung Bluetooth Classic / SPP. Beberapa printer BLE memerlukan SDK khusus.",14,0xFF65756B,false));}
    private boolean hasBtPermission(){if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},101);return false;}return true;}
    private void choosePrinter(){if(!hasBtPermission())return;BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null){toast("HP ini tidak mendukung Bluetooth");return;}if(!a.isEnabled()){toast("Aktifkan Bluetooth di Pengaturan HP terlebih dahulu");return;}try{Set<BluetoothDevice> devices=a.getBondedDevices();if(devices.isEmpty()){toast("Belum ada printer dipasangkan. Pasangkan melalui Pengaturan Bluetooth Android.");return;}ArrayList<BluetoothDevice> list=new ArrayList<>(devices);String[] names=new String[list.size()];for(int i=0;i<list.size();i++)names[i]=list.get(i).getName()+"\n"+list.get(i).getAddress();new AlertDialog.Builder(this).setTitle("Pilih Perangkat Bluetooth").setItems(names,(d,which)->{printerAddress=list.get(which).getAddress();prefs.edit().putString("printer",printerAddress).apply();show("Bluetooth");toast("Printer dipilih");}).setNegativeButton("Batal",null).show();}catch(SecurityException e){toast("Izin Bluetooth belum diberikan");}}
    private void printReceipt(String receipt){if(printerAddress.isEmpty()){new AlertDialog.Builder(this).setTitle("Printer belum dipilih").setMessage("Pilih printer Bluetooth yang sudah dipasangkan terlebih dahulu.").setPositiveButton("Pilih Printer",(d,w)->choosePrinter()).setNegativeButton("Batal",null).show();return;}if(!hasBtPermission())return;String address=printerAddress;Executors.newSingleThreadExecutor().execute(()->{BluetoothSocket socket=null;try{BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();BluetoothDevice dev=a.getRemoteDevice(address);socket=dev.createRfcommSocketToServiceRecord(SPP);socket.connect();OutputStream out=socket.getOutputStream();out.write(new byte[]{0x1B,0x40});out.write(receipt.getBytes("CP437"));out.write(new byte[]{0x1D,0x56,0x00});out.flush();socket.close();runOnUiThread(()->toast("Perintah cetak dikirim"));}catch(Exception e){try{if(socket!=null)socket.close();}catch(Exception ignored){}runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Gagal mencetak").setMessage("Periksa printer, koneksi Bluetooth, dan kompatibilitas printer SPP. Detail: "+e.getMessage()).setPositiveButton("OK",null).show());}});}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
